
import os
import uuid
import cv2
import joblib
import numpy as np

from skimage.feature import hog
from flask import Flask, render_template, request
from werkzeug.utils import secure_filename

app = Flask(__name__)

# ==========================================
# CONFIGURATION
# ==========================================

BASE_DIR = os.path.dirname(os.path.abspath(__file__))

MODEL_PATH = os.path.join(BASE_DIR, "logo_dataset.pkl")
UPLOAD_FOLDER = os.path.join(BASE_DIR, "static", "uploads")

ALLOWED_EXTENSIONS = {"jpg", "jpeg", "png"}

IMG_SIZE = 128
MAX_IMAGE_SIZE = 5 * 1024 * 1024

app.config["UPLOAD_FOLDER"] = UPLOAD_FOLDER
app.config["MAX_CONTENT_LENGTH"] = 25 * 1024 * 1024

os.makedirs(UPLOAD_FOLDER, exist_ok=True)

# ==========================================
# LOAD TRAINED MODEL
# ==========================================

model = None
BRAND_NAMES = {}

try:
    data = joblib.load(MODEL_PATH)

    model = data["model"]
    IMG_SIZE = int(data.get("img_size", 128))

    logo_names = data.get("logo_names", {})

    if isinstance(logo_names, dict):
        for key, value in logo_names.items():
            if isinstance(value, (int, np.integer)):
                BRAND_NAMES[int(value)] = str(key).title()
            elif isinstance(key, (int, np.integer)):
                BRAND_NAMES[int(key)] = str(value).title()

    print("Logo model loaded successfully!")
    print("Image size:", IMG_SIZE)
    print("Available brands:", BRAND_NAMES)

except Exception as e:
    print("Model loading error:", e)


# ==========================================
# IMAGE VALIDATION
# ==========================================

def allowed_file(filename):
    return (
        "." in filename
        and filename.rsplit(".", 1)[1].lower() in ALLOWED_EXTENSIONS
    )


# ==========================================
# HOG FEATURE EXTRACTION
# IMPORTANT: Must match train.py
# ==========================================

def extract_features(image_path):

    image = cv2.imread(image_path)

    if image is None:
        raise ValueError("Unable to read uploaded image.")

    image = cv2.resize(image, (IMG_SIZE, IMG_SIZE))

    gray = cv2.cvtColor(
        image,
        cv2.COLOR_BGR2GRAY
    )

    features = hog(
        gray,
        orientations=9,
        pixels_per_cell=(8, 8),
        cells_per_block=(2, 2),
        block_norm="L2-Hys"
    )

    return np.asarray(
        features,
        dtype=np.float32
    ).reshape(1, -1)


# ==========================================
# BRAND NAME
# ==========================================

def get_brand_name(prediction):

    if isinstance(prediction, (str, np.str_)):
        return str(prediction)

    try:
        return BRAND_NAMES.get(
            int(prediction),
            str(prediction)
        )
    except (ValueError, TypeError):
        return str(prediction)


# ==========================================
# HOME PAGE
# ==========================================

@app.route("/")
def home():
    return render_template("index.html")


# ==========================================
# LOGO PREDICTION
# ==========================================

@app.route("/predict", methods=["POST"])
def predict():

    if model is None:
        return render_template(
            "index.html",
            error="Model not loaded. Please check logo_dataset.pkl."
        )

    files = request.files.getlist("files")

    files = [
        file for file in files
        if file and file.filename
    ]

    if not files:
        single_file = request.files.get("file")

        if single_file and single_file.filename:
            files = [single_file]

    if not files:
        return render_template(
            "index.html",
            error="Please select at least one logo image."
        )

    results = []

    for file in files:

        original_name = secure_filename(file.filename)

        if not allowed_file(original_name):
            results.append({
                "error": original_name +
                ": Only JPG, JPEG and PNG are allowed."
            })
            continue

        file_bytes = file.read()

        if len(file_bytes) == 0:
            results.append({
                "error": original_name + ": Empty image file."
            })
            continue

        if len(file_bytes) > MAX_IMAGE_SIZE:
            results.append({
                "error": original_name +
                ": Image must be smaller than 5 MB."
            })
            continue

        # Validate image
        image_array = np.frombuffer(
            file_bytes,
            dtype=np.uint8
        )

        decoded = cv2.imdecode(
            image_array,
            cv2.IMREAD_COLOR
        )

        if decoded is None:
            results.append({
                "error": original_name +
                ": Invalid image file."
            })
            continue

        filename = (
            str(uuid.uuid4()) +
            "_" +
            original_name
        )

        filepath = os.path.join(
            UPLOAD_FOLDER,
            filename
        )

        try:

            with open(filepath, "wb") as output:
                output.write(file_bytes)

            # Extract HOG features
            features = extract_features(filepath)

            # Predict brand
            prediction = model.predict(features)[0]

            predicted_logo = get_brand_name(prediction)

            # Confidence
            confidence = None

            if hasattr(model, "predict_proba"):

                probabilities = model.predict_proba(
                    features
                )[0]

                confidence = round(
                    float(np.max(probabilities)) * 100,
                    2
                )

            results.append({
                "filename": filename,
                "original_name": original_name,
                "predicted_logo": predicted_logo,
                "confidence": confidence
            })

        except Exception as e:

            if os.path.exists(filepath):
                os.remove(filepath)

            results.append({
                "error": original_name +
                ": " + str(e)
            })

    return render_template(
        "index.html",
        results=results
    )


# ==========================================
# FILE SIZE ERROR
# ==========================================

@app.errorhandler(413)
def file_too_large(error):

    return render_template(
        "index.html",
        error="Total upload size is too large. Maximum 25 MB."
    ), 413


# ==========================================
# RUN APPLICATION
# ==========================================

if __name__ == "__main__":
    app.run(debug=True)
