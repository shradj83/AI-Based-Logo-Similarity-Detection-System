
import os
import cv2
import numpy as np
import joblib

from skimage.feature import hog
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import StandardScaler
from sklearn.svm import SVC

# ==========================================
# CONFIGURATION
# ==========================================

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
DATASET_PATH = os.path.join(BASE_DIR, "dataset")
MODEL_PATH = os.path.join(BASE_DIR, "logo_dataset.pkl")

IMG_SIZE = 128

# ==========================================
# FEATURE EXTRACTION
# ==========================================

def extract_features(image_path):

    image = cv2.imread(image_path)

    if image is None:
        return None

    image = cv2.resize(image, (IMG_SIZE, IMG_SIZE))
    gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)

    features = hog(
        gray,
        orientations=9,
        pixels_per_cell=(8, 8),
        cells_per_block=(2, 2),
        block_norm="L2-Hys",
        feature_vector=True
    )

    return features


# ==========================================
# LOAD DATASET
# ==========================================

X = []
y = []

print("=" * 45)
print("LOGO RECOGNITION - TRAINING")
print("=" * 45)

if not os.path.exists(DATASET_PATH):
    print("Dataset folder not found:", DATASET_PATH)
    exit()

brand_folders = sorted(
    folder for folder in os.listdir(DATASET_PATH)
    if os.path.isdir(os.path.join(DATASET_PATH, folder))
)

for brand in brand_folders:

    brand_path = os.path.join(DATASET_PATH, brand)
    image_count = 0

    for file in os.listdir(brand_path):

        if file.lower().endswith((".jpg", ".jpeg", ".png", ".bmp", ".webp")):

            image_path = os.path.join(brand_path, file)

            feature = extract_features(image_path)

            if feature is not None:
                X.append(feature)
                y.append(brand)
                image_count += 1

    print(f"{brand}: {image_count} images")

# ==========================================
# CHECK DATA
# ==========================================

if len(X) == 0:
    print("No valid images found.")
    exit()

X = np.array(X)
y = np.array(y)

print("\nTotal images:", len(X))
print("Total brands:", len(np.unique(y)))

# ==========================================
# TRAIN MODEL
# ==========================================

model = Pipeline([
    ("scaler", StandardScaler()),
    ("classifier", SVC(
        kernel="linear",
        C=1.0,
        probability=True,
        class_weight="balanced"
    ))
])

model.fit(X, y)

# ==========================================
# SAVE MODEL
# ==========================================

model_data = {
    "model": model,
    "img_size": IMG_SIZE,
    "logo_names": {
        brand: brand for brand in sorted(np.unique(y))
    },
    "feature_type": "HOG"
}

joblib.dump(model_data, MODEL_PATH)

print("\n" + "=" * 45)
print("TRAINING COMPLETED")
print("=" * 45)

print("Model saved:", MODEL_PATH)
print("Brands:", sorted(np.unique(y)))
print("Images trained:", len(X))
