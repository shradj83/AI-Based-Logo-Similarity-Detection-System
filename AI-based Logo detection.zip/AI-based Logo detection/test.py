
import os
import cv2
import joblib
import numpy as np

from skimage.feature import hog
from sklearn.metrics import accuracy_score, classification_report
from sklearn.model_selection import train_test_split

# ==========================================
# LOGO RECOGNITION - TESTING
# ==========================================

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
DATASET_DIR = os.path.join(BASE_DIR, "dataset")
MODEL_PATH = os.path.join(BASE_DIR, "logo_dataset.pkl")

IMG_SIZE = 128

print("=" * 45)
print("LOGO RECOGNITION - TESTING")
print("=" * 45)

# Load model
saved_data = joblib.load(MODEL_PATH)
model = saved_data["model"]

IMG_SIZE = saved_data.get("img_size", IMG_SIZE)

print("Model loaded successfully!")

# HOG feature extraction
def extract_features(image_path):

    image = cv2.imread(image_path)

    if image is None:
        return None

    image = cv2.resize(image, (IMG_SIZE, IMG_SIZE))
    gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)

    features = hog(
        gray,
        orientations=9,
        pixels_per_cell=(8, 8),
        cells_per_block=(2, 2),
        block_norm="L2-Hys"
    )

    return features


X = []
y = []

# Load dataset
for brand in sorted(os.listdir(DATASET_DIR)):

    brand_path = os.path.join(DATASET_DIR, brand)

    if not os.path.isdir(brand_path):
        continue

    for file in os.listdir(brand_path):

        if file.lower().endswith((".jpg", ".jpeg", ".png")):

            image_path = os.path.join(brand_path, file)

            features = extract_features(image_path)

            if features is not None:
                X.append(features)
                y.append(brand)

                print("Loaded:", brand, "-", file)

X = np.array(X)
y = np.array(y)

print("\nTotal images:", len(X))
print("Total brands:", len(np.unique(y)))
print("Feature count:", X.shape[1])

# Split dataset
X_train, X_test, y_train, y_test = train_test_split(
    X,
    y,
    test_size=0.30,
    random_state=42,
    stratify=y
)

# Predict
predictions = model.predict(X_test)

# Results
accuracy = accuracy_score(y_test, predictions)

print("\n" + "=" * 45)
print("TESTING RESULTS")
print("=" * 45)

print("Accuracy:", round(accuracy * 100, 2), "%")

print("\nClassification Report:\n")

print(classification_report(
    y_test,
    predictions,
    zero_division=0
))

print("=" * 45)
print("TESTING COMPLETED")
print("=" * 45)
